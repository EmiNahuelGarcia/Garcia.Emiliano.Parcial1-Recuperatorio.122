/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Exceptions;

/**
 *
 * @author User
 */
public class EspectaculoExistenteException extends RuntimeException{
    
    private static final String MESSAGE = "Ya existe un evento con ese nombre y fecha ";
    
    public EspectaculoExistenteException(){
        this(MESSAGE);
    }
    
    public EspectaculoExistenteException(String mensaje){
        super(mensaje);
    }
    
}
    
