/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package garcia.emiliano.parcial1.recuperatorio.pkg122;

import Exceptions.EspectaculoExistenteException;
import Model.ClasificacionEdad;
import Model.Concierto;
import Model.Festival;
import Model.GeneroMusical;
import Model.GestorEspectaculos;
import Model.ObraTeatral;
import java.time.LocalDate;
import java.util.Arrays;

/**
 *
 * @author User
 */
public class GarciaEmilianoParcial1Recuperatorio122 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        GestorEspectaculos gestor = new GestorEspectaculos();
        
        System.out.println("\n--- Agregando eventos ---");
        try {
                Concierto concierto1 = new Concierto( "Quilmes Rock", LocalDate.of(2025, 6, 17), 125, GeneroMusical.ROCK);
                concierto1.agregarArtista("babasonicos");
                concierto1.agregarArtista("miranda");
                concierto1.agregarArtista("los redondos");

                gestor.agregarEspectaculo(concierto1);


                ObraTeatral obra1 = new ObraTeatral("Hamlet",LocalDate.of(2025, 6, 21), 90, ClasificacionEdad.MAYOR13, "Chespirito");
                gestor.agregarEspectaculo(obra1);

           
                Festival festival1 = new Festival( "Lolla", LocalDate.of(2025, 6, 22), 360, 5,true);
                gestor.agregarEspectaculo(festival1);
                
                
                Concierto conciertoError = new Concierto("Quilmes Rock",LocalDate.of(2025, 6, 17), 50, GeneroMusical.POP);
                conciertoError.agregarArtista("No te va a gustar");
                gestor.agregarEspectaculo(conciertoError);
                }catch (EspectaculoExistenteException e) {
                System.err.println(e.getMessage());
            }

           
                System.out.println("\n--- Mostrando Espectaculos ---");
                gestor.mostrarEspectaculos();

            
                System.out.println("\n--- Transmitiendo Eventos ---");
                gestor.transmitirEventos();

           
                System.out.println("\n--- Conciertos de genero ROCK ---");
                gestor.filtrarPorGenero(GeneroMusical.ROCK);

            
                System.out.println("\n--- Calificaciones ---");
                gestor.calificarEvento("QuilmesRock", 9);
                gestor.calificarEvento("Quilmes Rock", 10);
                gestor.calificarEvento("Hamlet", 8);
                gestor.calificarEvento("Lolla", 10); 

            
            
        
    }
}
