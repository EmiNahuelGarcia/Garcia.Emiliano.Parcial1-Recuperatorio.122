/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Transmitible;
import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Festival extends Espectaculo implements Transmitible {
    private int cantidadEscenarios;
    private boolean zonaCamping;
    

    public Festival(String nombre, LocalDate fecha, int duracion,
        int cantidadEscenarios, boolean zonaCamping){
        super(nombre, fecha, duracion);
        this.cantidadEscenarios = cantidadEscenarios;
        this.zonaCamping = zonaCamping;
    }

    public int getCantidadEscenarios() {
        return cantidadEscenarios;
    }

    public boolean tieneZonaCamping() {
        return zonaCamping;
    }
    
    

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo el Festival " + getNombre() + " en " + cantidadEscenarios + " escenarios");
    }

    @Override
    public String toString() {
        return super.toString() + ", Festival con la cantidad de escenarios de  : " + cantidadEscenarios + ", y camping : " + (zonaCamping ? "Si tiene" : "No tiene");
}

    
    

}
