/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Calificable;
import Interfaces.Transmitible;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author User
 */
public class Concierto extends Espectaculo implements Transmitible, Calificable {
    private GeneroMusical genero;
    private List<String> artistas;

    public Concierto(String nombre, LocalDate fecha, int duracion,
        GeneroMusical genero) {
        super(nombre, fecha, duracion);
        this.genero = genero;
        this.artistas = new ArrayList<>();
    }
    
    public void agregarArtista(String artista){
        artistas.add(artista);
    }

    public GeneroMusical getGenero() {
        return genero;
    }

   

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo concierto: " + getNombre());
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println("Concierto :" + getNombre() + " tiene una puntuacion de : " + puntaje);
    }

    @Override
    public String toString() {
        return super.toString() + " Concierto de genero : " + genero + ", con los artistas : " + artistas;
}
    

}