/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Interfaces.Calificable;
import java.time.LocalDate;


public class ObraTeatral extends Espectaculo implements Calificable {
    private ClasificacionEdad clasificacion;
    private String nombreDirector;

    public ObraTeatral(String nombre, LocalDate fecha, int duracion,
        ClasificacionEdad clasificacion, String nombreDirector){
        super(nombre, fecha, duracion);
        this.clasificacion = clasificacion;
        this.nombreDirector = nombreDirector;
    }

    
    

    @Override
    public void calificar(int puntaje) {
        System.out.println("Obra de teatro " + getNombre() + ", del director " + nombreDirector + ", saco un puntaje de : " + puntaje );
    }
    
    
   @Override
    public String toString() {
        return super.toString() + ", Obra teatral de clasificacion : " + clasificacion + ", del director : " + nombreDirector;
}




}
