/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Exceptions.EspectaculoExistenteException;
import Interfaces.Calificable;
import Interfaces.Transmitible;
import Model.Espectaculo;
import java.util.ArrayList;
import java.util.List;


public class GestorEspectaculos {
    private List<Espectaculo> espectaculos;

    public GestorEspectaculos() {
        this.espectaculos = new ArrayList<>();
    }
    
    

    public void agregarEspectaculo(Espectaculo e){
        validarEspectaculo(e);
        espectaculos.add(e);
        System.out.println("Espectaculo agregado " + e.getNombre());
    
    }
    
    private void validarEspectaculo(Espectaculo e) {
        if (e == null) {
            throw new NullPointerException("Espectaculo nulo");
        }
        if (espectaculos.contains(e)) {
            throw new EspectaculoExistenteException();
        }
    }
            
    

    public void mostrarEspectaculos(){
    for (Espectaculo e : espectaculos) {
        System.out.println(e); 
    }
}

    public void transmitirEventos() {
        validarVacia();
        for (Espectaculo e : espectaculos) {
            if (e instanceof Transmitible t) {
                t.transmitir();
            } else {
                System.out.println("El evento: " + e.getNombre() + " no se puede transmitir");
            }
        }
    }
    
    private void validarVacia(){
        if(espectaculos.isEmpty()){
            System.out.println("no hay eventos para transmitir");
            
        }
    }
        

    public List<Concierto> filtrarPorGenero(GeneroMusical g){
        ArrayList<Concierto> conciertosFiltrados = new ArrayList<>();
    
        for(Espectaculo e : espectaculos){
            if(e instanceof Concierto){
                Concierto c = (Concierto)e;
                if(c.getGenero()== g){
                    conciertosFiltrados.add(c);
                    System.out.println(c);
                }
            }
        }
        return conciertosFiltrados;
        
    }

    public void calificarEvento(String nombre, int puntaje) {
        for (Espectaculo e : espectaculos) {
            if (e.getNombre().equals(nombre)) {
                if (e instanceof Calificable c) {
                    c.calificar(puntaje);
                } else {
                    System.out.println("El espectaculo " + e.getNombre() + " no es calificable");
                }
                return;
            }
        }
        System.out.println("Ningun espectaculo se llama asi.");
    }
}
