/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author User
 */
public abstract class Espectaculo {
    
    String nombre;
    LocalDate fecha;
    int duracion;

    public Espectaculo(String nombre, LocalDate fecha, int duracion) {
        validarDuracion(duracion);
        this.nombre = nombre;
        this.fecha = fecha;
        this.duracion = duracion;
    }
    
    public void validarDuracion(int duracion){
        if (duracion <= 0){
        throw new IllegalArgumentException("La duración debe ser mayor a cero.");
    }
}
   

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public String toString() {
        return "Espectaculo : " + getNombre() + ", con la fecha : " + getFecha() + ", con la duracion de : " +  getDuracion() + " minutos ";
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, fecha);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || !(obj instanceof Espectaculo e)) {
            return false;
        }
        return this.nombre.equals(e.nombre) && this.fecha.equals(e.fecha);
    }
    
    
    
    
    
}
    


